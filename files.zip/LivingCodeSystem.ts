/**
 * Self-Modifying Code Intelligence System
 * Implements runtime code evolution with safety guarantees
 *
 * Design notes (corrections):
 * - No double execution: execution is measured once; evolution applies to next call.
 * - Safe mutation compiles a new function but does not run it during mutation.
 * - Async-aware metrics: Promise results update metrics post-resolution without blocking.
 * - Cross-runtime timing: uses performance.now() when available; falls back to Date.now().
 * - Memory metrics via process.memoryUsage() when available (Node), else undefined.
 * - Removed placeholder mutation that injected 'await' into non-async contexts.
 * - Bounded evolution with constraints; forbidden ops check before compilation.
 *
 * References: /reference vault, MDN Proxy, OWASP Eval Risks, Acorn (AST placeholder)
 */

interface CodeDNA {
  signature: string;
  mutations: number;
  fitness: number;
  parentHash: string;
  executionContext: Record<string, any>;
}

interface SafetyConstraints {
  maxMutations: number;
  forbiddenOps: string[]; // e.g., ['eval', 'Function', 'process.exit']
  maxExecTimeMs: number;  // threshold to consider evolution
  minFitness: number;     // not fully used; placeholder for advanced scoring
}

interface PerformanceMetrics {
  execTimeMs: number;
  memoryUsage?: number;
  error?: any;
  callCount: number;
}

type EvolvingFunction = (...args: any[]) => any;

class LivingCodeSystem {
  private codeGenome = new Map<string, CodeDNA>();

  createEvolvingFunction(initialCode: string, constraints: SafetyConstraints): EvolvingFunction {
    const safeConstraints = this.normalizeConstraints(constraints);
    let currentCode = initialCode.trim();
    let currentFn = this.compileFunction(currentCode, safeConstraints);

    const dna: CodeDNA = {
      signature: this.hashCode(currentCode),
      mutations: 0,
      fitness: 1,
      parentHash: '',
      executionContext: {},
    };
    this.codeGenome.set(dna.signature, dna);

    let evolving = false;

    const wrapper: EvolvingFunction = (...args: any[]) => {
      const start = this.now();
      let result: any;
      let error: any = undefined;

      try {
        result = currentFn(...args);
      } catch (e) {
        error = e;
      }

      const afterResolve = (err: any, res: any) => {
        const end = this.now();
        const mem = this.heapUsed();
        const metrics: PerformanceMetrics = {
          execTimeMs: end - start,
          memoryUsage: mem,
          error: err,
          callCount: 1,
        };
        // Non-blocking evolution for NEXT call
        if (!evolving && this.shouldEvolve(metrics, dna, safeConstraints)) {
          evolving = true;
          queueMicrotask(() => {
            try {
              if (dna.mutations < safeConstraints.maxMutations) {
                const mutated = this.generateMutation(currentCode, metrics);
                const compiled = this.compileFunction(mutated, safeConstraints);
                dna.parentHash = dna.signature;
                currentCode = mutated;
                currentFn = compiled;
                dna.signature = this.hashCode(mutated);
                dna.mutations += 1;
              }
            } catch (_e) {
              // Swallow mutation errors; retain currentFn
            } finally {
              evolving = false;
            }
          });
        }
      };

      if (error !== undefined) {
        afterResolve(error, undefined);
        throw error;
      }

      if (this.isPromise(result)) {
        (result as Promise<any>)
          .then(r => afterResolve(undefined, r))
          .catch(e => afterResolve(e, undefined));
        return result;
      } else {
        afterResolve(undefined, result);
        return result;
      }
    };

    // Optional: retain proxy shape (maintain compatibility with prior interface)
    return new Proxy(wrapper, {
      apply: (target, thisArg, args) => target.apply(thisArg, args),
    });
  }

  private compileFunction(code: string, constraints: SafetyConstraints): Function {
    this.enforceForbiddenOps(code, constraints.forbiddenOps);
    // Hardened compilation: avoid global eval; expect code to evaluate to a function
    const factory = new Function(`"use strict"; return (${code});`);
    const fn = factory();
    if (typeof fn !== 'function') {
      throw new Error('Compiled code is not a function.');
    }
    return fn as Function;
  }

  private enforceForbiddenOps(code: string, forbidden: string[]) {
    for (const op of forbidden) {
      if (op && code.includes(op)) {
        throw new Error(`Forbidden operation detected: ${op}`);
      }
    }
  }

  private shouldEvolve(metrics: PerformanceMetrics, dna: CodeDNA, constraints: SafetyConstraints): boolean {
    if (dna.mutations >= constraints.maxMutations) return false;
    if (metrics.error) return true;
    if (metrics.execTimeMs > constraints.maxExecTimeMs) return true;
    if (dna.fitness < constraints.minFitness) return true;
    return false;
  }

  private generateMutation(code: string, metrics: PerformanceMetrics): string {
    // Placeholder mutation rules; ensure syntactic validity
    let mutated = code;

    // Loop hinting: annotate for future optimizer passes
    mutated = mutated.replace(/for\s*\(.*\)\s*{/, match => `/* optimized */ ${match}`);

    // Simple memoization hint for Math.pow calls
    if (/Math\.pow/.test(mutated) && !/memoizedPow/.test(mutated)) {
      const prelude =
        `const __memo = new Map();` +
        `const memoizedPow = (a,b)=>{const k=a+':'+b; if(__memo.has(k)) return __memo.get(k); const v=Math.pow(a,b); __memo.set(k,v); return v;};`;
      mutated = `((...args)=>{ ${prelude} return (${code})(...args); })`;
    }

    return mutated;
  }

  // Utilities

  private now(): number {
    if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
      return performance.now();
    }
    return Date.now();
  }

  private heapUsed(): number | undefined {
    try {
      // @ts-ignore Node.js
      if (typeof process !== 'undefined' && process.memoryUsage) {
        // @ts-ignore Node.js
        return process.memoryUsage().heapUsed;
      }
    } catch (_) { /* noop */ }
    return undefined;
  }

  private isPromise(x: any): x is Promise<any> {
    return x && typeof x.then === 'function' && typeof x.catch === 'function';
  }

  private normalizeConstraints(c: SafetyConstraints): SafetyConstraints {
    return {
      maxMutations: Math.max(0, c?.maxMutations ?? 5),
      forbiddenOps: Array.isArray(c?.forbiddenOps) ? c.forbiddenOps : ['process.exit', 'require', 'import(', 'Function('],
      maxExecTimeMs: Math.max(0, c?.maxExecTimeMs ?? 100),
      minFitness: c?.minFitness ?? 1,
    };
  }

  private hashCode(code: string): string {
    // Lightweight hash (non-cryptographic)
    let h = 0;
    for (let i = 0; i < code.length; i++) {
      h = Math.imul(31, h) + code.charCodeAt(i) | 0;
    }
    return ('00000000' + (h >>> 0).toString(16)).slice(-8);
  }
}

export { LivingCodeSystem, CodeDNA, SafetyConstraints, PerformanceMetrics, EvolvingFunction };

/*
References:
- /reference vault (runtime safety, dynamic code, AST evolution)
- MDN Proxy: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy
- OWASP Eval Risks: https://cheatsheetseries.owasp.org/cheatsheets/Eval_in_JavaScript_Cheat_Sheet.html
- Acorn (AST placeholder): https://github.com/acornjs/acorn
*/